# Fruit > 2022-10-12 11:29pm
https://universe.roboflow.com/fruitfinding-robot/fruit-boah1

Provided by a Roboflow user
License: CC BY 4.0

